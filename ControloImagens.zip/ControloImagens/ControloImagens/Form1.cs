﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControloImagens
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lstVO_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void pic1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {

        }

        private void pic1_Click_1(object sender, EventArgs e)
        {

        }
        //Imagem 3
        private void cbo_SelectedIndexChanged(object sender, EventArgs e)
        {
                pic3.Visible = true;
        }
        //Imagem 1
        private void chkPic1_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPic1.Checked) {
                pic1.Visible = true;
            }
            else
            {
                pic1.Visible = false;
            }
        }
        //Imagem 2 - Ocultar
        private void rcbOcultar_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbOcultar.Checked)
            {
                pic2.Visible = false;
            }
        }
        //Imagem 2 - Ver
        private void rdbVer_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbVer.Checked)
            {
                pic2.Visible = true;
            }
        }
    }
}
