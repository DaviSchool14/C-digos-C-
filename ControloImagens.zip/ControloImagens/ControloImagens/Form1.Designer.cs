﻿namespace ControloImagens
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblImagens = new System.Windows.Forms.Label();
            this.grp = new System.Windows.Forms.GroupBox();
            this.rdbOcultar = new System.Windows.Forms.RadioButton();
            this.rdbVer = new System.Windows.Forms.RadioButton();
            this.cbo = new System.Windows.Forms.ComboBox();
            this.pic2 = new System.Windows.Forms.PictureBox();
            this.pic3 = new System.Windows.Forms.PictureBox();
            this.pic4 = new System.Windows.Forms.PictureBox();
            this.lstPic4 = new System.Windows.Forms.ListBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.chkPic1 = new System.Windows.Forms.CheckBox();
            this.pic1 = new System.Windows.Forms.PictureBox();
            this.grp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblImagens
            // 
            this.lblImagens.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblImagens.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblImagens.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblImagens.Font = new System.Drawing.Font("Montserrat Medium", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImagens.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblImagens.Location = new System.Drawing.Point(0, 0);
            this.lblImagens.Name = "lblImagens";
            this.lblImagens.Size = new System.Drawing.Size(214, 450);
            this.lblImagens.TabIndex = 0;
            this.lblImagens.Text = "VER/OCULTAR IMAGENS";
            this.lblImagens.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblImagens.Click += new System.EventHandler(this.label1_Click);
            // 
            // grp
            // 
            this.grp.Controls.Add(this.rdbOcultar);
            this.grp.Controls.Add(this.rdbVer);
            this.grp.Font = new System.Drawing.Font("Montserrat", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grp.Location = new System.Drawing.Point(351, 12);
            this.grp.Name = "grp";
            this.grp.Size = new System.Drawing.Size(90, 70);
            this.grp.TabIndex = 1;
            this.grp.TabStop = false;
            this.grp.Text = "Imagem 2";
            // 
            // rdbOcultar
            // 
            this.rdbOcultar.AutoSize = true;
            this.rdbOcultar.Checked = true;
            this.rdbOcultar.Location = new System.Drawing.Point(6, 43);
            this.rdbOcultar.Name = "rdbOcultar";
            this.rdbOcultar.Size = new System.Drawing.Size(65, 21);
            this.rdbOcultar.TabIndex = 1;
            this.rdbOcultar.TabStop = true;
            this.rdbOcultar.Text = "Ocultar";
            this.rdbOcultar.UseVisualStyleBackColor = true;
            this.rdbOcultar.CheckedChanged += new System.EventHandler(this.rcbOcultar_CheckedChanged);
            // 
            // rdbVer
            // 
            this.rdbVer.AutoSize = true;
            this.rdbVer.Location = new System.Drawing.Point(6, 20);
            this.rdbVer.Name = "rdbVer";
            this.rdbVer.Size = new System.Drawing.Size(44, 21);
            this.rdbVer.TabIndex = 0;
            this.rdbVer.Text = "Ver";
            this.rdbVer.UseVisualStyleBackColor = true;
            this.rdbVer.CheckedChanged += new System.EventHandler(this.rdbVer_CheckedChanged);
            // 
            // cbo
            // 
            this.cbo.FormattingEnabled = true;
            this.cbo.Items.AddRange(new object[] {
            "Imagem 3"});
            this.cbo.Location = new System.Drawing.Point(464, 12);
            this.cbo.Name = "cbo";
            this.cbo.Size = new System.Drawing.Size(121, 21);
            this.cbo.TabIndex = 2;
            this.cbo.SelectedIndexChanged += new System.EventHandler(this.cbo_SelectedIndexChanged);
            // 
            // pic2
            // 
            this.pic2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic2.Image = global::ControloImagens.Properties.Resources.Porto;
            this.pic2.Location = new System.Drawing.Point(351, 204);
            this.pic2.Name = "pic2";
            this.pic2.Size = new System.Drawing.Size(120, 120);
            this.pic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic2.TabIndex = 4;
            this.pic2.TabStop = false;
            this.pic2.Visible = false;
            // 
            // pic3
            // 
            this.pic3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic3.Image = global::ControloImagens.Properties.Resources.Viseu;
            this.pic3.Location = new System.Drawing.Point(477, 204);
            this.pic3.Name = "pic3";
            this.pic3.Size = new System.Drawing.Size(120, 120);
            this.pic3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic3.TabIndex = 5;
            this.pic3.TabStop = false;
            this.pic3.Visible = false;
            // 
            // pic4
            // 
            this.pic4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic4.Image = global::ControloImagens.Properties.Resources.Leiria;
            this.pic4.Location = new System.Drawing.Point(602, 204);
            this.pic4.Name = "pic4";
            this.pic4.Size = new System.Drawing.Size(120, 120);
            this.pic4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic4.TabIndex = 6;
            this.pic4.TabStop = false;
            this.pic4.Visible = false;
            // 
            // lstPic4
            // 
            this.lstPic4.Font = new System.Drawing.Font("Montserrat", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstPic4.FormattingEnabled = true;
            this.lstPic4.ItemHeight = 17;
            this.lstPic4.Location = new System.Drawing.Point(604, 12);
            this.lstPic4.Name = "lstPic4";
            this.lstPic4.Size = new System.Drawing.Size(120, 89);
            this.lstPic4.TabIndex = 7;
            this.lstPic4.SelectedIndexChanged += new System.EventHandler(this.lstVO_SelectedIndexChanged);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(283, 339);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(346, 35);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(283, 380);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(346, 35);
            this.btnSair.TabIndex = 9;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.button2_Click);
            // 
            // chkPic1
            // 
            this.chkPic1.AutoSize = true;
            this.chkPic1.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPic1.Location = new System.Drawing.Point(234, 12);
            this.chkPic1.Name = "chkPic1";
            this.chkPic1.Size = new System.Drawing.Size(100, 24);
            this.chkPic1.TabIndex = 10;
            this.chkPic1.Text = "Ver/Ocultar";
            this.chkPic1.UseVisualStyleBackColor = true;
            this.chkPic1.CheckedChanged += new System.EventHandler(this.chkPic1_CheckedChanged);
            // 
            // pic1
            // 
            this.pic1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic1.Image = global::ControloImagens.Properties.Resources.Lisboa;
            this.pic1.Location = new System.Drawing.Point(224, 204);
            this.pic1.Name = "pic1";
            this.pic1.Size = new System.Drawing.Size(120, 120);
            this.pic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic1.TabIndex = 11;
            this.pic1.TabStop = false;
            this.pic1.Visible = false;
            this.pic1.Click += new System.EventHandler(this.pic1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 450);
            this.Controls.Add(this.pic1);
            this.Controls.Add(this.chkPic1);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lstPic4);
            this.Controls.Add(this.pic4);
            this.Controls.Add(this.pic3);
            this.Controls.Add(this.pic2);
            this.Controls.Add(this.cbo);
            this.Controls.Add(this.grp);
            this.Controls.Add(this.lblImagens);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grp.ResumeLayout(false);
            this.grp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblImagens;
        private System.Windows.Forms.GroupBox grp;
        private System.Windows.Forms.RadioButton rdbOcultar;
        private System.Windows.Forms.ComboBox cbo;
        private System.Windows.Forms.PictureBox pic2;
        private System.Windows.Forms.PictureBox pic3;
        private System.Windows.Forms.PictureBox pic4;
        private System.Windows.Forms.ListBox lstPic4;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.CheckBox chkPic1;
        private System.Windows.Forms.PictureBox pic1;
        private System.Windows.Forms.RadioButton rdbVer;
    }
}

