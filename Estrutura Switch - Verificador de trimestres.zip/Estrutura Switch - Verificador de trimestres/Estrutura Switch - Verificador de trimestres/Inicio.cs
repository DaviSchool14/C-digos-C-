﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estrutura_Switch___Verificador_de_trimestres
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }
        //Botão iniciar
        private void btnInicio_Click(object sender, EventArgs e)
        {
            Trimestre Verificador = new Trimestre();

            Verificador.Show();

            this.Hide();
        }
        //Botão sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
