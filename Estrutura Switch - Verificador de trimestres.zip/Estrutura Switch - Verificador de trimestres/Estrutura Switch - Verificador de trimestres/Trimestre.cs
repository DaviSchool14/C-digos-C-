﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Estrutura_Switch___Verificador_de_trimestres
{
    public partial class Trimestre : Form
    {
        public Trimestre()
        {
            InitializeComponent();
        }
    }
}
