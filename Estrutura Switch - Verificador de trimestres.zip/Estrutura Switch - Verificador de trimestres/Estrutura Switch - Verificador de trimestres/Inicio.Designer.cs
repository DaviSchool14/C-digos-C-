﻿namespace Estrutura_Switch___Verificador_de_trimestres
{
    partial class Inicio
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSwitch = new System.Windows.Forms.Label();
            this.btnInicio = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblAutor = new System.Windows.Forms.Label();
            this.picLogos = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picLogos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSwitch
            // 
            this.lblSwitch.AutoSize = true;
            this.lblSwitch.Font = new System.Drawing.Font("Montserrat", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSwitch.ForeColor = System.Drawing.Color.Snow;
            this.lblSwitch.Location = new System.Drawing.Point(126, 34);
            this.lblSwitch.Name = "lblSwitch";
            this.lblSwitch.Size = new System.Drawing.Size(556, 75);
            this.lblSwitch.TabIndex = 0;
            this.lblSwitch.Text = "ESTRUTURA SWITCH";
            // 
            // btnInicio
            // 
            this.btnInicio.BackColor = System.Drawing.SystemColors.Desktop;
            this.btnInicio.Font = new System.Drawing.Font("Montserrat", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInicio.ForeColor = System.Drawing.Color.Snow;
            this.btnInicio.Location = new System.Drawing.Point(276, 158);
            this.btnInicio.Name = "btnInicio";
            this.btnInicio.Size = new System.Drawing.Size(310, 60);
            this.btnInicio.TabIndex = 1;
            this.btnInicio.Text = "INICIAR";
            this.btnInicio.UseVisualStyleBackColor = false;
            this.btnInicio.Click += new System.EventHandler(this.btnInicio_Click);
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.SystemColors.Desktop;
            this.btnSair.Font = new System.Drawing.Font("Montserrat", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.Color.Snow;
            this.btnSair.Location = new System.Drawing.Point(276, 247);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(310, 60);
            this.btnSair.TabIndex = 2;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // lblAutor
            // 
            this.lblAutor.AutoSize = true;
            this.lblAutor.Font = new System.Drawing.Font("Montserrat", 8.249999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAutor.ForeColor = System.Drawing.Color.Snow;
            this.lblAutor.Location = new System.Drawing.Point(12, 424);
            this.lblAutor.Name = "lblAutor";
            this.lblAutor.Size = new System.Drawing.Size(141, 17);
            this.lblAutor.TabIndex = 3;
            this.lblAutor.Text = "FEITO POR: DAVI SILVA";
            this.lblAutor.Click += new System.EventHandler(this.label1_Click);
            // 
            // picLogos
            // 
            this.picLogos.Image = global::Estrutura_Switch___Verificador_de_trimestres.Properties.Resources.Logos_removebg_preview;
            this.picLogos.Location = new System.Drawing.Point(426, 380);
            this.picLogos.Name = "picLogos";
            this.picLogos.Size = new System.Drawing.Size(373, 71);
            this.picLogos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogos.TabIndex = 4;
            this.picLogos.TabStop = false;
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.picLogos);
            this.Controls.Add(this.lblAutor);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnInicio);
            this.Controls.Add(this.lblSwitch);
            this.Name = "Inicio";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picLogos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSwitch;
        private System.Windows.Forms.Button btnInicio;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblAutor;
        private System.Windows.Forms.PictureBox picLogos;
    }
}

