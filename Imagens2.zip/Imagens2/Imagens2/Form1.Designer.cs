﻿namespace Imagens2
{
    partial class lblNada
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.chb = new System.Windows.Forms.CheckBox();
            this.grb = new System.Windows.Forms.GroupBox();
            this.rbnOcultar = new System.Windows.Forms.RadioButton();
            this.rbnVer = new System.Windows.Forms.RadioButton();
            this.cbn = new System.Windows.Forms.ComboBox();
            this.pic1 = new System.Windows.Forms.PictureBox();
            this.pic2 = new System.Windows.Forms.PictureBox();
            this.pic3 = new System.Windows.Forms.PictureBox();
            this.pic4 = new System.Windows.Forms.PictureBox();
            this.lsb = new System.Windows.Forms.ListBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limparToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.grb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic4)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Left;
            this.label1.Font = new System.Drawing.Font("Montserrat Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(0, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 426);
            this.label1.TabIndex = 0;
            this.label1.Text = "VER/OCULTAR IMAGENS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chb
            // 
            this.chb.AutoSize = true;
            this.chb.Location = new System.Drawing.Point(192, 38);
            this.chb.Name = "chb";
            this.chb.Size = new System.Drawing.Size(42, 17);
            this.chb.TabIndex = 1;
            this.chb.Text = "Ver";
            this.chb.UseVisualStyleBackColor = true;
            this.chb.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // grb
            // 
            this.grb.Controls.Add(this.rbnOcultar);
            this.grb.Controls.Add(this.rbnVer);
            this.grb.Location = new System.Drawing.Point(303, 38);
            this.grb.Name = "grb";
            this.grb.Size = new System.Drawing.Size(75, 73);
            this.grb.TabIndex = 2;
            this.grb.TabStop = false;
            this.grb.Text = "IMAGEM 2";
            // 
            // rbnOcultar
            // 
            this.rbnOcultar.AutoSize = true;
            this.rbnOcultar.Checked = true;
            this.rbnOcultar.Location = new System.Drawing.Point(6, 42);
            this.rbnOcultar.Name = "rbnOcultar";
            this.rbnOcultar.Size = new System.Drawing.Size(59, 17);
            this.rbnOcultar.TabIndex = 1;
            this.rbnOcultar.TabStop = true;
            this.rbnOcultar.Text = "Ocultar";
            this.rbnOcultar.UseVisualStyleBackColor = true;
            // 
            // rbnVer
            // 
            this.rbnVer.AutoSize = true;
            this.rbnVer.Location = new System.Drawing.Point(6, 19);
            this.rbnVer.Name = "rbnVer";
            this.rbnVer.Size = new System.Drawing.Size(41, 17);
            this.rbnVer.TabIndex = 0;
            this.rbnVer.Text = "Ver";
            this.rbnVer.UseVisualStyleBackColor = true;
            this.rbnVer.CheckedChanged += new System.EventHandler(this.rbnVer_CheckedChanged);
            // 
            // cbn
            // 
            this.cbn.FormattingEnabled = true;
            this.cbn.Items.AddRange(new object[] {
            "Imagem 3"});
            this.cbn.Location = new System.Drawing.Point(413, 34);
            this.cbn.Name = "cbn";
            this.cbn.Size = new System.Drawing.Size(121, 21);
            this.cbn.TabIndex = 3;
            this.cbn.SelectedIndexChanged += new System.EventHandler(this.cbn_SelectedIndexChanged);
            // 
            // pic1
            // 
            this.pic1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic1.Enabled = false;
            this.pic1.Image = global::Imagens2.Properties.Resources.Lisboa;
            this.pic1.Location = new System.Drawing.Point(162, 177);
            this.pic1.Name = "pic1";
            this.pic1.Size = new System.Drawing.Size(120, 120);
            this.pic1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic1.TabIndex = 4;
            this.pic1.TabStop = false;
            this.pic1.Visible = false;
            // 
            // pic2
            // 
            this.pic2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic2.Enabled = false;
            this.pic2.Image = global::Imagens2.Properties.Resources.Porto;
            this.pic2.Location = new System.Drawing.Point(288, 177);
            this.pic2.Name = "pic2";
            this.pic2.Size = new System.Drawing.Size(120, 120);
            this.pic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic2.TabIndex = 5;
            this.pic2.TabStop = false;
            this.pic2.Visible = false;
            // 
            // pic3
            // 
            this.pic3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic3.Enabled = false;
            this.pic3.Image = global::Imagens2.Properties.Resources.Viseu;
            this.pic3.Location = new System.Drawing.Point(414, 177);
            this.pic3.Name = "pic3";
            this.pic3.Size = new System.Drawing.Size(120, 120);
            this.pic3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic3.TabIndex = 6;
            this.pic3.TabStop = false;
            this.pic3.Visible = false;
            // 
            // pic4
            // 
            this.pic4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic4.Enabled = false;
            this.pic4.Image = global::Imagens2.Properties.Resources.Leiria;
            this.pic4.Location = new System.Drawing.Point(540, 177);
            this.pic4.Name = "pic4";
            this.pic4.Size = new System.Drawing.Size(120, 120);
            this.pic4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic4.TabIndex = 7;
            this.pic4.TabStop = false;
            this.pic4.Visible = false;
            // 
            // lsb
            // 
            this.lsb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lsb.FormattingEnabled = true;
            this.lsb.Items.AddRange(new object[] {
            "Ver",
            "Ocultar"});
            this.lsb.Location = new System.Drawing.Point(540, 34);
            this.lsb.Name = "lsb";
            this.lsb.Size = new System.Drawing.Size(120, 93);
            this.lsb.TabIndex = 8;
            this.lsb.SelectedIndexChanged += new System.EventHandler(this.lsb_SelectedIndexChanged);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(162, 319);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(498, 46);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(162, 371);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(498, 46);
            this.btnSair.TabIndex = 10;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.limparToolStripMenuItem,
            this.sairToolStripMenuItem,
            this.sairToolStripMenuItem1});
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.menuToolStripMenuItem.Text = "Menu";
            // 
            // limparToolStripMenuItem
            // 
            this.limparToolStripMenuItem.Name = "limparToolStripMenuItem";
            this.limparToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.limparToolStripMenuItem.Text = "Limpar";
            this.limparToolStripMenuItem.Click += new System.EventHandler(this.limparToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(177, 6);
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem1
            // 
            this.sairToolStripMenuItem1.Name = "sairToolStripMenuItem1";
            this.sairToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem1.Text = "Sair";
            this.sairToolStripMenuItem1.Click += new System.EventHandler(this.sairToolStripMenuItem1_Click);
            // 
            // lblNada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lsb);
            this.Controls.Add(this.pic4);
            this.Controls.Add(this.pic3);
            this.Controls.Add(this.pic2);
            this.Controls.Add(this.pic1);
            this.Controls.Add(this.cbn);
            this.Controls.Add(this.grb);
            this.Controls.Add(this.chb);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "lblNada";
            this.Text = "VER/OCULTAR IMAGENS";
            this.grb.ResumeLayout(false);
            this.grb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic4)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chb;
        private System.Windows.Forms.GroupBox grb;
        private System.Windows.Forms.RadioButton rbnVer;
        private System.Windows.Forms.ComboBox cbn;
        private System.Windows.Forms.PictureBox pic1;
        private System.Windows.Forms.PictureBox pic2;
        private System.Windows.Forms.PictureBox pic3;
        private System.Windows.Forms.PictureBox pic4;
        private System.Windows.Forms.RadioButton rbnOcultar;
        private System.Windows.Forms.ListBox lsb;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem limparToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem1;
    }
}

