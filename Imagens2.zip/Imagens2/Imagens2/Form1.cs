﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Imagens2
{
    public partial class lblNada : Form
    {
        public lblNada()
        {
            InitializeComponent();
        }
        //Imagem 1
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            pic1.Visible = chb.Checked;
        }
        //Imagem 2
        private void rbnVer_CheckedChanged(object sender, EventArgs e)
        {
            pic2.Visible = rbnVer.Checked;
        }
        //Imagem 3
        private void cbn_SelectedIndexChanged(object sender, EventArgs e)
        {
         
                pic3.Visible = true;
            
           
        }
    }
}
