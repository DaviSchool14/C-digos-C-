﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Imagens2
{
    public partial class lblNada : Form
    {
        public lblNada()
        {
            InitializeComponent();
        }
        //Imagem 1
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            pic1.Visible = chb.Checked;
        }
        //Imagem 2
        private void rbnVer_CheckedChanged(object sender, EventArgs e)
        {
            pic2.Visible = rbnVer.Checked;
        }
        //Imagem 3
        private void cbn_SelectedIndexChanged(object sender, EventArgs e)
        {
                pic3.Visible = true;
        }
        //Imagem 4
        private void lsb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsb.SelectedIndex == 0)
            {
                pic4.Visible = true;
            }
            else
            {
                pic4.Visible = false;
            }
        }
        //Botão sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            // Botão sair
        {
            DialogResult resp;

            resp = MessageBox.Show("Deseja realmente sair?", "Confirmar Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resp == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        }
        //Botão limpar
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            pic1.Image = null;
            pic2.Image = null;
            pic3.Image = null;
            pic4.Image = null;
            chb.Checked = false;
            rbnVer.Checked = false;
            cbn.SelectedIndex = -1;
            lsb.SelectedIndex = -1;
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        //Menu - Limpar
        private void limparToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnLimpar_Click(sender, e);
        }
        //Menu - Sair
        private void sairToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            btnSair_Click(sender, e);
        }
    }
}
