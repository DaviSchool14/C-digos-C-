﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Métodos___Retângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Funções
        private double CalPerimetro (double Largura, double Comprimento)
        {
            return 2 * (Largura + Comprimento);
        }

        private double CalcArea (double Largura, double Comprimento)
        {
            return Largura * Comprimento;
        }

        private bool Quadrado (double Largura, double Comprimento)
        {
            if (Largura == Comprimento)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private double CalcDiagonal (double Largura, double Comprimento)
        {
            return Math.Sqrt(Largura* Largura + Comprimento* Comprimento);
        }

        //----------------------------------------------------------------------------------------------------------------

        //Botão - Sair
        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        //Botão - Limpar
        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtLargura.Text = "";
            TxtComprimento.Text = "";
            LblResultado.Text = "";
        }

        //Ficheiros - Limpar
        private void limparToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnLimpar_Click(sender, e);
        }

        //Botão - Perímetro
        private void BtnPerimetro_Click(object sender, EventArgs e)
        {
            double Largura, Comprimento, Perimetro;

            Largura = Convert.ToDouble(TxtLargura.Text);
            Comprimento = Convert.ToDouble(TxtComprimento.Text);
            //--------------------------------------------------

            LblResultado.Text = "PERÍMETRO = " + CalPerimetro(Largura, Comprimento);
        }

        //Botão - É um quadrado?
        private void BtnQuadrado_Click(object sender, EventArgs e)
        {
            double Largura, Comprimento;

            Largura = Convert.ToDouble(TxtLargura.Text);
            Comprimento = Convert.ToDouble(TxtComprimento.Text);
            //--------------------------------------------------

            if (Quadrado(Largura, Comprimento))
            {
                LblResultado.Text = "É UM QUADRADO";
            }
            else
            {
                LblResultado.Text = "NÃO É UM QUADRADO";
            }
        }

        //Botão - Área
        private void BtnArea_Click(object sender, EventArgs e)
        {
            double Largura, Comprimento;

            Largura = Convert.ToDouble(TxtLargura.Text);
            Comprimento = Convert.ToDouble(TxtComprimento.Text);
            //--------------------------------------------------

            LblResultado.Text = "ÁREA = " + CalcArea(Largura, Comprimento);
        }

        //Botão - Diagonal
        private void BtnDiagonal_Click(object sender, EventArgs e)
        {
            double Largura, Comprimento;

            Largura = Convert.ToDouble(TxtLargura.Text);
            Comprimento = Convert.ToDouble(TxtComprimento.Text);
            //--------------------------------------------------

            LblResultado.Text = "DIAGONAL = " + CalcDiagonal(Largura, Comprimento);
        }

        //Ficheiros - Sair
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnSair_Click(sender, e);
        }
    }
}
