﻿namespace Métodos___Retângulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblInsLargura = new System.Windows.Forms.Label();
            this.LblInsComprimento = new System.Windows.Forms.Label();
            this.TxtLargura = new System.Windows.Forms.TextBox();
            this.TxtComprimento = new System.Windows.Forms.TextBox();
            this.LblResultado = new System.Windows.Forms.Label();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ficheirosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limparToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BtnPerimetro = new System.Windows.Forms.Button();
            this.BtnArea = new System.Windows.Forms.Button();
            this.BtnDiagonal = new System.Windows.Forms.Button();
            this.BtnQuadrado = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // LblInsLargura
            // 
            this.LblInsLargura.AutoSize = true;
            this.LblInsLargura.Font = new System.Drawing.Font("Geist", 24F, System.Drawing.FontStyle.Bold);
            this.LblInsLargura.Location = new System.Drawing.Point(105, 63);
            this.LblInsLargura.Name = "LblInsLargura";
            this.LblInsLargura.Size = new System.Drawing.Size(181, 43);
            this.LblInsLargura.TabIndex = 0;
            this.LblInsLargura.Text = "LARGURA:";
            // 
            // LblInsComprimento
            // 
            this.LblInsComprimento.AutoSize = true;
            this.LblInsComprimento.Font = new System.Drawing.Font("Geist", 24F, System.Drawing.FontStyle.Bold);
            this.LblInsComprimento.Location = new System.Drawing.Point(12, 118);
            this.LblInsComprimento.Name = "LblInsComprimento";
            this.LblInsComprimento.Size = new System.Drawing.Size(274, 43);
            this.LblInsComprimento.TabIndex = 1;
            this.LblInsComprimento.Text = "COMPRIMENTO:";
            // 
            // TxtLargura
            // 
            this.TxtLargura.Font = new System.Drawing.Font("Geist", 24F, System.Drawing.FontStyle.Bold);
            this.TxtLargura.Location = new System.Drawing.Point(292, 60);
            this.TxtLargura.Name = "TxtLargura";
            this.TxtLargura.Size = new System.Drawing.Size(217, 49);
            this.TxtLargura.TabIndex = 2;
            // 
            // TxtComprimento
            // 
            this.TxtComprimento.Font = new System.Drawing.Font("Geist", 24F, System.Drawing.FontStyle.Bold);
            this.TxtComprimento.Location = new System.Drawing.Point(292, 118);
            this.TxtComprimento.Name = "TxtComprimento";
            this.TxtComprimento.Size = new System.Drawing.Size(217, 49);
            this.TxtComprimento.TabIndex = 3;
            // 
            // LblResultado
            // 
            this.LblResultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblResultado.Font = new System.Drawing.Font("Geist", 24F, System.Drawing.FontStyle.Bold);
            this.LblResultado.Location = new System.Drawing.Point(97, 184);
            this.LblResultado.Name = "LblResultado";
            this.LblResultado.Size = new System.Drawing.Size(576, 90);
            this.LblResultado.TabIndex = 4;
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Font = new System.Drawing.Font("Geist", 18F, System.Drawing.FontStyle.Bold);
            this.BtnLimpar.Location = new System.Drawing.Point(628, 44);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(151, 51);
            this.BtnLimpar.TabIndex = 5;
            this.BtnLimpar.Text = "LIMPAR";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.Font = new System.Drawing.Font("Geist", 18F, System.Drawing.FontStyle.Bold);
            this.BtnSair.Location = new System.Drawing.Point(628, 101);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(151, 51);
            this.BtnSair.TabIndex = 6;
            this.BtnSair.Text = "SAIR";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ficheirosToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ficheirosToolStripMenuItem
            // 
            this.ficheirosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.limparToolStripMenuItem,
            this.toolStripMenuItem1,
            this.sairToolStripMenuItem});
            this.ficheirosToolStripMenuItem.Name = "ficheirosToolStripMenuItem";
            this.ficheirosToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.ficheirosToolStripMenuItem.Text = "Ficheiros";
            // 
            // limparToolStripMenuItem
            // 
            this.limparToolStripMenuItem.Name = "limparToolStripMenuItem";
            this.limparToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.limparToolStripMenuItem.Text = "Limpar";
            this.limparToolStripMenuItem.Click += new System.EventHandler(this.limparToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(177, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // BtnPerimetro
            // 
            this.BtnPerimetro.Font = new System.Drawing.Font("Geist Medium", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPerimetro.Location = new System.Drawing.Point(97, 303);
            this.BtnPerimetro.Name = "BtnPerimetro";
            this.BtnPerimetro.Size = new System.Drawing.Size(251, 51);
            this.BtnPerimetro.TabIndex = 8;
            this.BtnPerimetro.Text = "PERÍMETRO";
            this.BtnPerimetro.UseVisualStyleBackColor = true;
            this.BtnPerimetro.Click += new System.EventHandler(this.BtnPerimetro_Click);
            // 
            // BtnArea
            // 
            this.BtnArea.Font = new System.Drawing.Font("Geist Medium", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnArea.Location = new System.Drawing.Point(422, 303);
            this.BtnArea.Name = "BtnArea";
            this.BtnArea.Size = new System.Drawing.Size(251, 51);
            this.BtnArea.TabIndex = 9;
            this.BtnArea.Text = "ÁREA";
            this.BtnArea.UseVisualStyleBackColor = true;
            this.BtnArea.Click += new System.EventHandler(this.BtnArea_Click);
            // 
            // BtnDiagonal
            // 
            this.BtnDiagonal.Font = new System.Drawing.Font("Geist Medium", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDiagonal.Location = new System.Drawing.Point(97, 371);
            this.BtnDiagonal.Name = "BtnDiagonal";
            this.BtnDiagonal.Size = new System.Drawing.Size(251, 51);
            this.BtnDiagonal.TabIndex = 10;
            this.BtnDiagonal.Text = "DIAGONAL";
            this.BtnDiagonal.UseVisualStyleBackColor = true;
            this.BtnDiagonal.Click += new System.EventHandler(this.BtnDiagonal_Click);
            // 
            // BtnQuadrado
            // 
            this.BtnQuadrado.Font = new System.Drawing.Font("Geist Medium", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnQuadrado.Location = new System.Drawing.Point(422, 371);
            this.BtnQuadrado.Name = "BtnQuadrado";
            this.BtnQuadrado.Size = new System.Drawing.Size(251, 51);
            this.BtnQuadrado.TabIndex = 11;
            this.BtnQuadrado.Text = "É UM QUADRADO?";
            this.BtnQuadrado.UseVisualStyleBackColor = true;
            this.BtnQuadrado.Click += new System.EventHandler(this.BtnQuadrado_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnQuadrado);
            this.Controls.Add(this.BtnDiagonal);
            this.Controls.Add(this.BtnArea);
            this.Controls.Add(this.BtnPerimetro);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.LblResultado);
            this.Controls.Add(this.TxtComprimento);
            this.Controls.Add(this.TxtLargura);
            this.Controls.Add(this.LblInsComprimento);
            this.Controls.Add(this.LblInsLargura);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblInsLargura;
        private System.Windows.Forms.Label LblInsComprimento;
        private System.Windows.Forms.TextBox TxtLargura;
        private System.Windows.Forms.TextBox TxtComprimento;
        private System.Windows.Forms.Label LblResultado;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ficheirosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem limparToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.Button BtnPerimetro;
        private System.Windows.Forms.Button BtnArea;
        private System.Windows.Forms.Button BtnDiagonal;
        private System.Windows.Forms.Button BtnQuadrado;
    }
}

