﻿namespace Ciclos___Loop
{
    partial class LOOP
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ficheiroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.limparToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblIN = new System.Windows.Forms.Label();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.txtIN = new System.Windows.Forms.TextBox();
            this.btnLinha = new System.Windows.Forms.Button();
            this.btnNumeroPares = new System.Windows.Forms.Button();
            this.btnDivisores = new System.Windows.Forms.Button();
            this.btnSomaNumeros = new System.Windows.Forms.Button();
            this.btnProgressaoAritmetica = new System.Windows.Forms.Button();
            this.btnVeirificarNumerosPrimos = new System.Windows.Forms.Button();
            this.btnTrianguloNumeros = new System.Windows.Forms.Button();
            this.btnConverterBinario = new System.Windows.Forms.Button();
            this.btnTrianguloAsteristicos = new System.Windows.Forms.Button();
            this.btnQuadradoAsteristicos = new System.Windows.Forms.Button();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Geist", 67F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.Location = new System.Drawing.Point(146, 24);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(302, 122);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "LOOP";
            this.lblTitulo.Click += new System.EventHandler(this.lblTitulo_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ficheiroToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(984, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ficheiroToolStripMenuItem
            // 
            this.ficheiroToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.limparToolStripMenuItem,
            this.toolStripMenuItem1,
            this.sairToolStripMenuItem});
            this.ficheiroToolStripMenuItem.Name = "ficheiroToolStripMenuItem";
            this.ficheiroToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.ficheiroToolStripMenuItem.Text = "Ficheiro";
            // 
            // limparToolStripMenuItem
            // 
            this.limparToolStripMenuItem.Name = "limparToolStripMenuItem";
            this.limparToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.limparToolStripMenuItem.Text = "Limpar";
            this.limparToolStripMenuItem.Click += new System.EventHandler(this.limparToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(177, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // lblIN
            // 
            this.lblIN.Font = new System.Drawing.Font("Geist SemiBold", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIN.Location = new System.Drawing.Point(12, 228);
            this.lblIN.Name = "lblIN";
            this.lblIN.Size = new System.Drawing.Size(375, 45);
            this.lblIN.TabIndex = 2;
            this.lblIN.Text = "INSIRA UM NÚMERO:";
            // 
            // picLogo
            // 
            this.picLogo.Image = global::Ciclos___Loop.Properties.Resources.LOOP___Logo;
            this.picLogo.Location = new System.Drawing.Point(12, 27);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(128, 121);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.TabIndex = 3;
            this.picLogo.TabStop = false;
            // 
            // txtIN
            // 
            this.txtIN.Font = new System.Drawing.Font("Geist", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIN.Location = new System.Drawing.Point(20, 288);
            this.txtIN.Name = "txtIN";
            this.txtIN.Size = new System.Drawing.Size(361, 53);
            this.txtIN.TabIndex = 4;
            // 
            // btnLinha
            // 
            this.btnLinha.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLinha.Location = new System.Drawing.Point(426, 218);
            this.btnLinha.Name = "btnLinha";
            this.btnLinha.Size = new System.Drawing.Size(104, 64);
            this.btnLinha.TabIndex = 5;
            this.btnLinha.Text = "LINHA";
            this.btnLinha.UseVisualStyleBackColor = true;
            this.btnLinha.Click += new System.EventHandler(this.btnLinha_Click);
            // 
            // btnNumeroPares
            // 
            this.btnNumeroPares.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumeroPares.Location = new System.Drawing.Point(536, 218);
            this.btnNumeroPares.Name = "btnNumeroPares";
            this.btnNumeroPares.Size = new System.Drawing.Size(104, 64);
            this.btnNumeroPares.TabIndex = 6;
            this.btnNumeroPares.Text = "NÚMEROS PARES";
            this.btnNumeroPares.UseVisualStyleBackColor = true;
            this.btnNumeroPares.Click += new System.EventHandler(this.btnNumeroPares_Click);
            // 
            // btnDivisores
            // 
            this.btnDivisores.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDivisores.Location = new System.Drawing.Point(646, 218);
            this.btnDivisores.Name = "btnDivisores";
            this.btnDivisores.Size = new System.Drawing.Size(104, 64);
            this.btnDivisores.TabIndex = 7;
            this.btnDivisores.Text = "DIVISORES";
            this.btnDivisores.UseVisualStyleBackColor = true;
            this.btnDivisores.Click += new System.EventHandler(this.btnDivisores_Click);
            // 
            // btnSomaNumeros
            // 
            this.btnSomaNumeros.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSomaNumeros.Location = new System.Drawing.Point(758, 218);
            this.btnSomaNumeros.Name = "btnSomaNumeros";
            this.btnSomaNumeros.Size = new System.Drawing.Size(104, 64);
            this.btnSomaNumeros.TabIndex = 8;
            this.btnSomaNumeros.Text = "SOMA DE NÚMEROS";
            this.btnSomaNumeros.UseVisualStyleBackColor = true;
            this.btnSomaNumeros.Click += new System.EventHandler(this.btnSomaNumeros_Click);
            // 
            // btnProgressaoAritmetica
            // 
            this.btnProgressaoAritmetica.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProgressaoAritmetica.Location = new System.Drawing.Point(868, 218);
            this.btnProgressaoAritmetica.Name = "btnProgressaoAritmetica";
            this.btnProgressaoAritmetica.Size = new System.Drawing.Size(104, 64);
            this.btnProgressaoAritmetica.TabIndex = 9;
            this.btnProgressaoAritmetica.Text = "PROGRESSÃO ARITMÉTICA";
            this.btnProgressaoAritmetica.UseVisualStyleBackColor = true;
            this.btnProgressaoAritmetica.Click += new System.EventHandler(this.btnProgressaoAritmetica_Click);
            // 
            // btnVeirificarNumerosPrimos
            // 
            this.btnVeirificarNumerosPrimos.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVeirificarNumerosPrimos.Location = new System.Drawing.Point(426, 288);
            this.btnVeirificarNumerosPrimos.Name = "btnVeirificarNumerosPrimos";
            this.btnVeirificarNumerosPrimos.Size = new System.Drawing.Size(104, 64);
            this.btnVeirificarNumerosPrimos.TabIndex = 10;
            this.btnVeirificarNumerosPrimos.Text = "VEIRIFICAR NÚMEROS PRIMOS";
            this.btnVeirificarNumerosPrimos.UseVisualStyleBackColor = true;
            // 
            // btnTrianguloNumeros
            // 
            this.btnTrianguloNumeros.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrianguloNumeros.Location = new System.Drawing.Point(868, 288);
            this.btnTrianguloNumeros.Name = "btnTrianguloNumeros";
            this.btnTrianguloNumeros.Size = new System.Drawing.Size(104, 64);
            this.btnTrianguloNumeros.TabIndex = 14;
            this.btnTrianguloNumeros.Text = "TRIÂNGULO DE NÚMEROS";
            this.btnTrianguloNumeros.UseVisualStyleBackColor = true;
            // 
            // btnConverterBinario
            // 
            this.btnConverterBinario.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConverterBinario.Location = new System.Drawing.Point(758, 288);
            this.btnConverterBinario.Name = "btnConverterBinario";
            this.btnConverterBinario.Size = new System.Drawing.Size(104, 64);
            this.btnConverterBinario.TabIndex = 13;
            this.btnConverterBinario.Text = "CONVERTER PARA BINÁRIO";
            this.btnConverterBinario.UseVisualStyleBackColor = true;
            // 
            // btnTrianguloAsteristicos
            // 
            this.btnTrianguloAsteristicos.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrianguloAsteristicos.Location = new System.Drawing.Point(646, 288);
            this.btnTrianguloAsteristicos.Name = "btnTrianguloAsteristicos";
            this.btnTrianguloAsteristicos.Size = new System.Drawing.Size(106, 64);
            this.btnTrianguloAsteristicos.TabIndex = 12;
            this.btnTrianguloAsteristicos.Text = "TRIÂNGULO DE ASTESRISTICOS";
            this.btnTrianguloAsteristicos.UseVisualStyleBackColor = true;
            // 
            // btnQuadradoAsteristicos
            // 
            this.btnQuadradoAsteristicos.Font = new System.Drawing.Font("Geist", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuadradoAsteristicos.Location = new System.Drawing.Point(536, 288);
            this.btnQuadradoAsteristicos.Name = "btnQuadradoAsteristicos";
            this.btnQuadradoAsteristicos.Size = new System.Drawing.Size(104, 64);
            this.btnQuadradoAsteristicos.TabIndex = 11;
            this.btnQuadradoAsteristicos.Text = "QUADRADO DE ASTERISTICOS";
            this.btnQuadradoAsteristicos.UseVisualStyleBackColor = true;
            this.btnQuadradoAsteristicos.Click += new System.EventHandler(this.btnQuadradoAsteristicos_Click);
            // 
            // txtResultado
            // 
            this.txtResultado.Font = new System.Drawing.Font("Geist", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResultado.Location = new System.Drawing.Point(426, 358);
            this.txtResultado.Multiline = true;
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtResultado.Size = new System.Drawing.Size(546, 311);
            this.txtResultado.TabIndex = 15;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Geist", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(20, 394);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(361, 64);
            this.btnLimpar.TabIndex = 16;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Geist", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(20, 487);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(361, 64);
            this.btnSair.TabIndex = 17;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // LOOP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 681);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.btnTrianguloNumeros);
            this.Controls.Add(this.btnConverterBinario);
            this.Controls.Add(this.btnTrianguloAsteristicos);
            this.Controls.Add(this.btnQuadradoAsteristicos);
            this.Controls.Add(this.btnVeirificarNumerosPrimos);
            this.Controls.Add(this.btnProgressaoAritmetica);
            this.Controls.Add(this.btnSomaNumeros);
            this.Controls.Add(this.btnDivisores);
            this.Controls.Add(this.btnNumeroPares);
            this.Controls.Add(this.btnLinha);
            this.Controls.Add(this.txtIN);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.lblIN);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Geist", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "LOOP";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.LOOP_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ficheiroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem limparToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.Label lblIN;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.TextBox txtIN;
        private System.Windows.Forms.Button btnLinha;
        private System.Windows.Forms.Button btnNumeroPares;
        private System.Windows.Forms.Button btnDivisores;
        private System.Windows.Forms.Button btnSomaNumeros;
        private System.Windows.Forms.Button btnProgressaoAritmetica;
        private System.Windows.Forms.Button btnVeirificarNumerosPrimos;
        private System.Windows.Forms.Button btnTrianguloNumeros;
        private System.Windows.Forms.Button btnConverterBinario;
        private System.Windows.Forms.Button btnTrianguloAsteristicos;
        private System.Windows.Forms.Button btnQuadradoAsteristicos;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

