﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ciclos___Loop
{
    public partial class LOOP : Form
    {
        public LOOP()
        {
            InitializeComponent();
        }

        //Ficheiro - Sair
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnSair_Click(sender, e);
        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {

        }

        private void LOOP_Load(object sender, EventArgs e)
        {

        }

        //Botão Sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo) == DialogResult.Yes)
             {
                Application.Exit();
             }
        }

        //Botão - Linha
        private void btnLinha_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "\n";

            if (int.TryParse(txtIN.Text, out int N))
            {
                int i = 0;

                while (i <= N)
                {
                    txtResultado.Text += "-";
                    i++;
                }
            }

            txtResultado.Text += "\n";
        }

        //Botão - Números pares
        private void btnNumeroPares_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";

            if (int.TryParse(txtIN.Text, out int N))
            {
                if (N % 2 != 0)
                {
                    N = N - 1;
                }

                int i = N;

                while (i >= 2)
                {
                    txtResultado.Text += i + " ";
                    i = i - 2;
                }
            }
        }

        //Botão - Divisores
        private void btnDivisores_Click(object sender, EventArgs e)
        {
            txtResultado.Text += "\n";

            if (int.TryParse(txtIN.Text, out int N))
            {
                int i = 1;

                while (i <= N)
                {
                    if (N % i == 0)
                    {
                        txtResultado.Text += i + " ";
                    }
                    i++;
                }

                txtResultado.Text += "\n";
            }
        }

        //Botão - Limpar
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";
            txtIN.Text = "";
        }

        //Botão - Soma de números
        private void btnSomaNumeros_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";

            if (int.TryParse(txtIN.Text, out int N))
            {
                int num = N, soma = 0;

                if (num < 0)
                {
                    num = num * -1; //Aqui deixa o negativo em positivo
                }

                while (num > 0)
                {
                    int algarismo = num % 10; //Aqui faz alguma coisa com os algarismos
                    soma = soma + algarismo;  //Sla como isso faz
                    num = num / 10;           //Sla também, mas faz algum calculo
                }

                txtResultado.Text = soma.ToString();

                txtResultado.Text = "\n";
            }
        }

        //Botão - Progressão aritmética
        private void btnProgressaoAritmetica_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "\n";

            if (int.TryParse(txtResultado.Text, out int N))
            {
                //Terminar progressão aritmética
                
                /*int i = 0, pa = 0, multiplicador = 0, r = 0;

                while (i <= N)
                {
                    while (pa <= N)
                    {
                        multiplicador += N + N;
                    }

                    r = multiplicador * i;
                }

                txtResultado.Text = r.ToString();*/
            }

            txtResultado.Text = "\n";
        }

        //Ficheiro - Limpar
        private void limparToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnLimpar_Click(sender, e);
        }

        //Botão - Quadrado de asteristicos
        private void btnQuadradoAsteristicos_Click(object sender, EventArgs e)
        {
            txtResultado.Text = "";

            if (int.TryParse(txtIN.Text, out int N))
            {
                int linha = 1;

                while (linha <= N)
                {
                    int coluna = 1;

                    while (coluna <= N)
                    {
                        txtResultado.Text += "*";
                        coluna++;
                    }

                    txtResultado.Text += "\n";
                    linha++;
                }
            }

            txtResultado.Text += "";
        }
    }
}