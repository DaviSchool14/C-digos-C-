﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Métodos___Retângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Variáveis globais
        double Largura, Comprimento;

        //Funções
        private double CalcArea() //Função de calcular a área
        {
            return Largura * Comprimento;
        }

        private double CalcDiagonal() //Função - Diagonal
        {
            return Math.Sqrt(Largura * Largura + Comprimento * Comprimento);
        }

        private void LerDados() //Função que vai ler os dados
        {
            Largura = Convert.ToDouble(TxtLargura.Text);
            Comprimento = Convert.ToDouble(TxtComprimento.Text);
        }

        private double CalcPerimetro() //Função que permite calcular o perímetro
        {
            double Per; //Variável local
                
            Per = 2 * (Comprimento + Largura);

            return Per;
        }

        private bool Quadrado()
        {
            if (Largura == Comprimento)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //----------------------------------------------------------------------------------------------------------------

        //Botão - Sair
        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        //Botão - Limpar
        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtLargura.Text = "";
            TxtComprimento.Text = "";
            LblResultado.Text = "";
        }

        //Ficheiros - Limpar
        private void limparToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnLimpar_Click(sender, e);
        }

        //Botão - Perímetro
        private void BtnPerimetro_Click(object sender, EventArgs e)
        {
            double Per;

            LerDados();

            Per = CalcPerimetro();

            LblResultado.Text = Per.ToString();
        }

        //Botão - É um quadrado?
        private void BtnQuadrado_Click(object sender, EventArgs e)
        {
            LerDados();

            if (Quadrado())
            {
                LblResultado.Text = "É UM QUADRADO";
            }
            else
            {
                LblResultado.Text = "NÃO É UM QUADRADO";
            }
        }

        //Botão - Área
        private void BtnArea_Click(object sender, EventArgs e)
        {
            LerDados();

            LblResultado.Text = "ÁREA = " + CalcArea();
        }

        //Botão - Diagonal
        private void BtnDiagonal_Click(object sender, EventArgs e)
        {
            LerDados();

            LblResultado.Text = "DIAGONAL = " + CalcDiagonal();
        }

        //Ficheiros - Sair
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnSair_Click(sender, e);
        }
    }
}
