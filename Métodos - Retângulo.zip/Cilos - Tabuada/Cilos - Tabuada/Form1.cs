﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cilos___Tabuada
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ficheiroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        //Ficheiro - Limpar
        private void limpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnLimpar_Click(sender, e);
        }

        //Botão - Sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        //Botão - Limpar
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lblResultado.Text = "";
            txtIN.Text = "";
        }

        //Botão - Calcular
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtIN.Text, out int number))
            {
                for (int i = 1; i <= 10; i++)
                {
                 lblResultado.Text += number.ToString() + "X" + i.ToString() + "=" + number * i + "\n";
                }
            }  
        }

        //Ficheiro - Sair
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnSair_Click(sender, e);
        }

        private void lblResultado_Click(object sender, EventArgs e)
        {

        }
    }
}
