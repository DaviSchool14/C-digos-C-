﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Métodos___Parâmetros_e_Argumentos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Botão - Sair
        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        //Botão - Limpar
        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtNumero1.Text = "";
            TxtNumero2.Text = "";
            LblResultado.Text = "";
        }

        //Ficheiro - Limpar
        private void limparToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnLimpar_Click((object)sender, e);
        }

        //Botão - Sair
        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BtnSair_Click((object)sender, e);
        }
    }
}
