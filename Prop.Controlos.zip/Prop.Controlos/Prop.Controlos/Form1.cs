﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prop.Controlos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Ação de mover nome
        private void btnMostrarNome_Click(object sender, EventArgs e)
        {
            lblVoid.Text = txtNome.Text.ToUpper();

            txtNome.Text = "";

            btnMostrarNome.Enabled = false;
            txtNome.Enabled = false;
        }
        //Logo 1 - VSCode
        private void btnLogoUm_Click(object sender, EventArgs e)
        {
            imgLogos.Image = Properties.Resources.vscode;
        }
        //Labbel - apresentar nome
        private void lblVoid_Click(object sender, EventArgs e)
        {
            
        }
        //Sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Caixa de texto
        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            
        }
        //Mover para a direita
        private void btnMR_Click(object sender, EventArgs e)
        {
            lblVoid.Left += 10;
        }
        //Mover para a esquerda
        private void btnML_Click(object sender, EventArgs e)
        {
            lblVoid.Left -= 10;
        }
        //Botão alterar font
        private void btnAlterarFont_Click(object sender, EventArgs e)
        {
            lblVoid.Font = new Font("Arial", 14);
        }
        //Botão limpar
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lblVoid.Text = "";
            lblVoid.Location = new Point(172, 395);

            btnMostrarNome.Enabled = true;
            txtNome.Enabled = true;
        }
        //Alinhar a direita
        private void btnAlinharDir_Click(object sender, EventArgs e)
        {
            lblVoid.TextAlign = ContentAlignment.MiddleRight;
        }
        //Alinhar a esquerda
        private void btnAlinharEsq_Click(object sender, EventArgs e)
        {
            lblVoid.TextAlign = ContentAlignment.MiddleLeft;
        }
        //Logo 2 - InteliJ
        private void btnLogoDois_Click(object sender, EventArgs e)
        {
            imgLogos.Image = Properties.Resources.intelij;
        }

        private void imgLogos_Click(object sender, EventArgs e)
        {

        }
    }
}
