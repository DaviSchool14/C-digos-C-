﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salarios
{
    public partial class Salários : Form
    {
        public Salários()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        //Botão Sair
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        //Botão Limpar
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtSalário.Text = "";           //Salário
            nudDias.Value = 0;              //Dias trabalhados
            nudFilhos.Value = 0;            //Quantidade der filhos
            lblCacSindicato.Text = "";      //Sindicato
            lblCacIRS.Text = "";            //IRS
            lblCacSS.Text = "";             //Segurança Social
            lblCacAlimentação.Text = "";    //Alimentação
            lblCacSalário.Text = "";        //Salário líquido
        }
        //Botão - Não (filhos)
        private void rbtNão_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtNão.Checked)
            {
                lblFilhos.Visible = false;
                nudFilhos.Visible = false;
            }
        }
        //Botão - Sim (filhos)
        private void rbtSim_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtSim.Checked)
            {
                lblFilhos.Visible = true;
                nudFilhos.Visible = true;
            }
        }
        //CheckBox - Sindicato
        private void cbkSindicalizado_CheckedChanged(object sender, EventArgs e)
        {
            if (cbkSindicalizado.Checked)
            {
                lblSindicato.Visible = true;
                lblCacSindicato.Visible = true;
            } else {
                lblSindicato.Visible = false;
                lblCacSindicato.Visible = false;
            }
        }
        //Botão - Calcular
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Declaração de variáveis
            double SalarioBruto, SegurancaSocial, Alimentacao, Sindicato = 0;
            double taxaIRS = 0.0;
            double valorIRS = 0;
            double SalarioLiquido;

            //Leitura dos dados de entrada
            SalarioBruto = Convert.ToDouble(txtSalário.Text);
            int diasTrabalho = Convert.ToInt32(nudDias.Value);

            // Identificar a quantidade de filhos (se marcou 'SIM', lê o valor do NumericUpDown, senão é 0)
            int numFilhos = rbtSim.Checked ? Convert.ToInt32(nudFilhos.Value) : 0;

            //Cálculos base (Segurança Social 11% e Subsídio de Alimentação 7€/dia)
            SegurancaSocial = SalarioBruto * 0.11;
            Alimentacao = diasTrabalho * 7;

            //Cálculo do Sindicato (1% se a CheckBox tiver marcada)
            if (cbkSindicalizado.Checked)
            {
                Sindicato = SalarioBruto * 0.01;
            }

            //Determinar a taxa de IRS com base no Salário, Estado Civil e N.º de Filhos
            if (SalarioBruto >= 900 && SalarioBruto <= 1100)
            {
                if (cbkCasado.Checked) // Se for Casado
                {
                    if (numFilhos == 0) taxaIRS = 0.12;
                    else if (numFilhos == 1) taxaIRS = 0.10;
                    else if (numFilhos == 2 || numFilhos == 3) taxaIRS = 0.09;
                    else if (numFilhos > 3) taxaIRS = 0.07;
                }
                else //Se NÃO for Casado
                {
                    if (numFilhos == 0) taxaIRS = 0.13;
                    else if (numFilhos == 1) taxaIRS = 0.11;
                    else if (numFilhos == 2 || numFilhos == 3) taxaIRS = 0.10;
                    else if (numFilhos > 3) taxaIRS = 0.08;
                }
            }
            else if (SalarioBruto > 1100)
            {
                if (cbkCasado.Checked) //Se for Casado
                {
                    if (numFilhos == 0) taxaIRS = 0.15;
                    else if (numFilhos == 1) taxaIRS = 0.12;
                    else if (numFilhos == 2 || numFilhos == 3) taxaIRS = 0.11;
                    else if (numFilhos > 3) taxaIRS = 0.09;
                }
                else //Se NÃO for Casado
                {
                    if (numFilhos == 0) taxaIRS = 0.17;
                    else if (numFilhos == 1) taxaIRS = 0.15;
                    else if (numFilhos == 2 || numFilhos == 3) taxaIRS = 0.13;
                    else if (numFilhos > 3) taxaIRS = 0.11;
                }
            }

            //Calcular o valor final do IRS em Euros
            valorIRS = SalarioBruto * taxaIRS;

            //Calcular o Salário Líquido final (Bruto - Descontos + Subsídio)
            SalarioLiquido = SalarioBruto - SegurancaSocial - Sindicato - valorIRS + Alimentacao;

            //Exibir todos os resultados na interface
            lblCacSindicato.Text = Sindicato.ToString("F2") + " €";
            lblCacIRS.Text = valorIRS.ToString("F2") + " €";
            lblCacSS.Text = SegurancaSocial.ToString("F2") + " €";
            lblCacAlimentação.Text = Alimentacao.ToString("F2") + " €";
            lblCacSalário.Text = SalarioLiquido.ToString("F2") + " €";
        }

        private void limparToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtSalário.Text = "";           //Salário
            nudDias.Value = 0;              //Dias trabalhados
            nudFilhos.Value = 0;            //Quantidade der filhos
            lblCacSindicato.Text = "";      //Sindicato
            lblCacIRS.Text = "";            //IRS
            lblCacSS.Text = "";             //Segurança Social
            lblCacAlimentação.Text = "";    //Alimentação
            lblCacSalário.Text = "";        //Salário líquido
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Sair", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
