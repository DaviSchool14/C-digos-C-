﻿namespace Salarios
{
    partial class Salários
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSalário = new System.Windows.Forms.Label();
            this.txtSalário = new System.Windows.Forms.TextBox();
            this.lblDias = new System.Windows.Forms.Label();
            this.nudDias = new System.Windows.Forms.NumericUpDown();
            this.cbkSindicalizado = new System.Windows.Forms.CheckBox();
            this.cbkCasado = new System.Windows.Forms.CheckBox();
            this.nudFilhos = new System.Windows.Forms.NumericUpDown();
            this.grpFilhos = new System.Windows.Forms.GroupBox();
            this.rbtNão = new System.Windows.Forms.RadioButton();
            this.rbtSim = new System.Windows.Forms.RadioButton();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblSindicato = new System.Windows.Forms.Label();
            this.lblIRS = new System.Windows.Forms.Label();
            this.lblSS = new System.Windows.Forms.Label();
            this.lblAlimentação = new System.Windows.Forms.Label();
            this.lblSalárioLIQ = new System.Windows.Forms.Label();
            this.lblCacSindicato = new System.Windows.Forms.Label();
            this.lblCacSalário = new System.Windows.Forms.Label();
            this.lblCacIRS = new System.Windows.Forms.Label();
            this.lblCacSS = new System.Windows.Forms.Label();
            this.lblCacAlimentação = new System.Windows.Forms.Label();
            this.btnSair = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nudDias)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).BeginInit();
            this.grpFilhos.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSalário
            // 
            this.lblSalário.AutoSize = true;
            this.lblSalário.Font = new System.Drawing.Font("Geist", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalário.Location = new System.Drawing.Point(12, 38);
            this.lblSalário.Name = "lblSalário";
            this.lblSalário.Size = new System.Drawing.Size(103, 26);
            this.lblSalário.TabIndex = 0;
            this.lblSalário.Text = "SALÁRIO:";
            // 
            // txtSalário
            // 
            this.txtSalário.Font = new System.Drawing.Font("Geist", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalário.Location = new System.Drawing.Point(228, 37);
            this.txtSalário.Name = "txtSalário";
            this.txtSalário.Size = new System.Drawing.Size(120, 27);
            this.txtSalário.TabIndex = 1;
            this.txtSalário.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblDias
            // 
            this.lblDias.AutoSize = true;
            this.lblDias.Font = new System.Drawing.Font("Geist", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDias.Location = new System.Drawing.Point(9, 73);
            this.lblDias.Name = "lblDias";
            this.lblDias.Size = new System.Drawing.Size(201, 26);
            this.lblDias.TabIndex = 2;
            this.lblDias.Text = "DIAS DE TRABALHO:";
            this.lblDias.Click += new System.EventHandler(this.label1_Click);
            // 
            // nudDias
            // 
            this.nudDias.Font = new System.Drawing.Font("Geist", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudDias.Location = new System.Drawing.Point(228, 73);
            this.nudDias.Name = "nudDias";
            this.nudDias.Size = new System.Drawing.Size(120, 27);
            this.nudDias.TabIndex = 3;
            // 
            // cbkSindicalizado
            // 
            this.cbkSindicalizado.AutoSize = true;
            this.cbkSindicalizado.Font = new System.Drawing.Font("Geist", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbkSindicalizado.Location = new System.Drawing.Point(17, 127);
            this.cbkSindicalizado.Name = "cbkSindicalizado";
            this.cbkSindicalizado.Size = new System.Drawing.Size(139, 24);
            this.cbkSindicalizado.TabIndex = 4;
            this.cbkSindicalizado.Text = "SINDICALIZADO";
            this.cbkSindicalizado.UseVisualStyleBackColor = true;
            this.cbkSindicalizado.CheckedChanged += new System.EventHandler(this.cbkSindicalizado_CheckedChanged);
            // 
            // cbkCasado
            // 
            this.cbkCasado.AutoSize = true;
            this.cbkCasado.Font = new System.Drawing.Font("Geist", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbkCasado.Location = new System.Drawing.Point(162, 127);
            this.cbkCasado.Name = "cbkCasado";
            this.cbkCasado.Size = new System.Drawing.Size(90, 24);
            this.cbkCasado.TabIndex = 5;
            this.cbkCasado.Text = "CASADO";
            this.cbkCasado.UseVisualStyleBackColor = true;
            // 
            // nudFilhos
            // 
            this.nudFilhos.Font = new System.Drawing.Font("Geist", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudFilhos.Location = new System.Drawing.Point(228, 222);
            this.nudFilhos.Name = "nudFilhos";
            this.nudFilhos.Size = new System.Drawing.Size(120, 27);
            this.nudFilhos.TabIndex = 6;
            this.nudFilhos.Visible = false;
            // 
            // grpFilhos
            // 
            this.grpFilhos.Controls.Add(this.rbtNão);
            this.grpFilhos.Controls.Add(this.rbtSim);
            this.grpFilhos.Font = new System.Drawing.Font("Geist", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpFilhos.Location = new System.Drawing.Point(14, 189);
            this.grpFilhos.Name = "grpFilhos";
            this.grpFilhos.Size = new System.Drawing.Size(192, 60);
            this.grpFilhos.TabIndex = 7;
            this.grpFilhos.TabStop = false;
            this.grpFilhos.Text = "TEM FILHOS?";
            // 
            // rbtNão
            // 
            this.rbtNão.AutoSize = true;
            this.rbtNão.Location = new System.Drawing.Point(118, 26);
            this.rbtNão.Name = "rbtNão";
            this.rbtNão.Size = new System.Drawing.Size(59, 24);
            this.rbtNão.TabIndex = 1;
            this.rbtNão.TabStop = true;
            this.rbtNão.Text = "NÃO";
            this.rbtNão.UseVisualStyleBackColor = true;
            this.rbtNão.CheckedChanged += new System.EventHandler(this.rbtNão_CheckedChanged);
            // 
            // rbtSim
            // 
            this.rbtSim.AutoSize = true;
            this.rbtSim.Location = new System.Drawing.Point(6, 26);
            this.rbtSim.Name = "rbtSim";
            this.rbtSim.Size = new System.Drawing.Size(54, 24);
            this.rbtSim.TabIndex = 0;
            this.rbtSim.TabStop = true;
            this.rbtSim.Text = "SIM";
            this.rbtSim.UseVisualStyleBackColor = true;
            this.rbtSim.CheckedChanged += new System.EventHandler(this.rbtSim_CheckedChanged);
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Font = new System.Drawing.Font("Geist", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilhos.Location = new System.Drawing.Point(224, 196);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(86, 20);
            this.lblFilhos.TabIndex = 8;
            this.lblFilhos.Text = "QUANTOS?";
            this.lblFilhos.Visible = false;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Geist", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(192, 293);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(156, 43);
            this.btnCalcular.TabIndex = 9;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Geist", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(16, 293);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(156, 43);
            this.btnLimpar.TabIndex = 10;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblSindicato
            // 
            this.lblSindicato.AutoSize = true;
            this.lblSindicato.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSindicato.Location = new System.Drawing.Point(433, 127);
            this.lblSindicato.Name = "lblSindicato";
            this.lblSindicato.Size = new System.Drawing.Size(94, 20);
            this.lblSindicato.TabIndex = 11;
            this.lblSindicato.Text = "SINDICATO:";
            this.lblSindicato.Visible = false;
            // 
            // lblIRS
            // 
            this.lblIRS.AutoSize = true;
            this.lblIRS.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIRS.Location = new System.Drawing.Point(433, 158);
            this.lblIRS.Name = "lblIRS";
            this.lblIRS.Size = new System.Drawing.Size(38, 20);
            this.lblIRS.TabIndex = 12;
            this.lblIRS.Text = "IRS:";
            // 
            // lblSS
            // 
            this.lblSS.AutoSize = true;
            this.lblSS.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSS.Location = new System.Drawing.Point(433, 188);
            this.lblSS.Name = "lblSS";
            this.lblSS.Size = new System.Drawing.Size(107, 20);
            this.lblSS.TabIndex = 13;
            this.lblSS.Text = "SEG. SOCIAL:";
            // 
            // lblAlimentação
            // 
            this.lblAlimentação.AutoSize = true;
            this.lblAlimentação.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlimentação.Location = new System.Drawing.Point(432, 219);
            this.lblAlimentação.Name = "lblAlimentação";
            this.lblAlimentação.Size = new System.Drawing.Size(153, 20);
            this.lblAlimentação.TabIndex = 14;
            this.lblAlimentação.Text = "SUB. ALIMENTAÇÃO";
            // 
            // lblSalárioLIQ
            // 
            this.lblSalárioLIQ.AutoSize = true;
            this.lblSalárioLIQ.Font = new System.Drawing.Font("Geist Black", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalárioLIQ.Location = new System.Drawing.Point(433, 252);
            this.lblSalárioLIQ.Name = "lblSalárioLIQ";
            this.lblSalárioLIQ.Size = new System.Drawing.Size(153, 20);
            this.lblSalárioLIQ.TabIndex = 15;
            this.lblSalárioLIQ.Text = "SALÁRIO LÍQUIDO:";
            // 
            // lblCacSindicato
            // 
            this.lblCacSindicato.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCacSindicato.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCacSindicato.Location = new System.Drawing.Point(605, 126);
            this.lblCacSindicato.Name = "lblCacSindicato";
            this.lblCacSindicato.Size = new System.Drawing.Size(108, 20);
            this.lblCacSindicato.TabIndex = 16;
            this.lblCacSindicato.Visible = false;
            // 
            // lblCacSalário
            // 
            this.lblCacSalário.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCacSalário.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCacSalário.Location = new System.Drawing.Point(605, 251);
            this.lblCacSalário.Name = "lblCacSalário";
            this.lblCacSalário.Size = new System.Drawing.Size(108, 20);
            this.lblCacSalário.TabIndex = 17;
            // 
            // lblCacIRS
            // 
            this.lblCacIRS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCacIRS.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCacIRS.Location = new System.Drawing.Point(605, 157);
            this.lblCacIRS.Name = "lblCacIRS";
            this.lblCacIRS.Size = new System.Drawing.Size(108, 20);
            this.lblCacIRS.TabIndex = 18;
            // 
            // lblCacSS
            // 
            this.lblCacSS.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCacSS.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCacSS.Location = new System.Drawing.Point(605, 188);
            this.lblCacSS.Name = "lblCacSS";
            this.lblCacSS.Size = new System.Drawing.Size(108, 20);
            this.lblCacSS.TabIndex = 19;
            // 
            // lblCacAlimentação
            // 
            this.lblCacAlimentação.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCacAlimentação.Font = new System.Drawing.Font("Geist SemiBold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCacAlimentação.Location = new System.Drawing.Point(605, 219);
            this.lblCacAlimentação.Name = "lblCacAlimentação";
            this.lblCacAlimentação.Size = new System.Drawing.Size(108, 20);
            this.lblCacAlimentação.TabIndex = 20;
            // 
            // btnSair
            // 
            this.btnSair.AutoSize = true;
            this.btnSair.Font = new System.Drawing.Font("Geist SemiBold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(16, 411);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(112, 27);
            this.btnSair.TabIndex = 21;
            this.btnSair.Text = "SAIR";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.Desktop;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Geist", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Snow;
            this.label1.Location = new System.Drawing.Point(523, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 61);
            this.label1.TabIndex = 22;
            this.label1.Text = "SALÁRIO LÍQUIDO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Salários
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.lblCacAlimentação);
            this.Controls.Add(this.lblCacSS);
            this.Controls.Add(this.lblCacIRS);
            this.Controls.Add(this.lblCacSalário);
            this.Controls.Add(this.lblCacSindicato);
            this.Controls.Add(this.lblSalárioLIQ);
            this.Controls.Add(this.lblAlimentação);
            this.Controls.Add(this.lblSS);
            this.Controls.Add(this.lblIRS);
            this.Controls.Add(this.lblSindicato);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.grpFilhos);
            this.Controls.Add(this.nudFilhos);
            this.Controls.Add(this.cbkCasado);
            this.Controls.Add(this.cbkSindicalizado);
            this.Controls.Add(this.nudDias);
            this.Controls.Add(this.lblDias);
            this.Controls.Add(this.txtSalário);
            this.Controls.Add(this.lblSalário);
            this.Name = "Salários";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudDias)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFilhos)).EndInit();
            this.grpFilhos.ResumeLayout(false);
            this.grpFilhos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSalário;
        private System.Windows.Forms.TextBox txtSalário;
        private System.Windows.Forms.Label lblDias;
        private System.Windows.Forms.NumericUpDown nudDias;
        private System.Windows.Forms.CheckBox cbkSindicalizado;
        private System.Windows.Forms.CheckBox cbkCasado;
        private System.Windows.Forms.NumericUpDown nudFilhos;
        private System.Windows.Forms.GroupBox grpFilhos;
        private System.Windows.Forms.RadioButton rbtSim;
        private System.Windows.Forms.RadioButton rbtNão;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblSindicato;
        private System.Windows.Forms.Label lblIRS;
        private System.Windows.Forms.Label lblSS;
        private System.Windows.Forms.Label lblAlimentação;
        private System.Windows.Forms.Label lblSalárioLIQ;
        private System.Windows.Forms.Label lblCacSindicato;
        private System.Windows.Forms.Label lblCacSalário;
        private System.Windows.Forms.Label lblCacIRS;
        private System.Windows.Forms.Label lblCacSS;
        private System.Windows.Forms.Label lblCacAlimentação;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label label1;
    }
}

